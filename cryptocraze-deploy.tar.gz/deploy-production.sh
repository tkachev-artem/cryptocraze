#!/bin/bash

set -e

echo "🚀 Starting CryptoCraze Production Deployment"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if .env.production exists
if [ ! -f ".env.production" ]; then
    echo -e "${RED}❌ .env.production file not found!${NC}"
    echo -e "${YELLOW}Please copy .env.production.example to .env.production and configure it${NC}"
    exit 1
fi

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo -e "${RED}❌ Docker is not running. Please start Docker first.${NC}"
    exit 1
fi

# Load environment variables
export $(cat .env.production | grep -v '^#' | xargs)

echo -e "${GREEN}✅ Environment loaded${NC}"

# Build the Docker image
echo -e "${YELLOW}🔨 Building Docker image...${NC}"
docker build -t cryptocraze:latest .

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Docker image built successfully${NC}"
else
    echo -e "${RED}❌ Docker build failed${NC}"
    exit 1
fi

# Stop existing containers if running
echo -e "${YELLOW}🛑 Stopping existing containers...${NC}"
docker-compose -f docker-compose.production.yml --env-file .env.production down

# Start the application
echo -e "${YELLOW}🚀 Starting application...${NC}"
docker-compose -f docker-compose.production.yml --env-file .env.production up -d

# Wait for services to be healthy
echo -e "${YELLOW}⏳ Waiting for services to be healthy...${NC}"
sleep 10

# Check health
echo -e "${YELLOW}🔍 Checking application health...${NC}"
timeout=60
counter=0

while [ $counter -lt $timeout ]; do
    if curl -f http://localhost:3001/health > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Application is healthy and running!${NC}"
        echo -e "${GREEN}🌐 Access your application at: http://localhost:3001${NC}"
        
        if [ ! -z "$TUNNEL_URL" ]; then
            echo -e "${GREEN}🌍 Public URL: $TUNNEL_URL${NC}"
        fi
        
        echo -e "${YELLOW}📊 View logs: docker-compose -f docker-compose.production.yml logs -f${NC}"
        echo -e "${YELLOW}🛑 Stop: docker-compose -f docker-compose.production.yml down${NC}"
        
        exit 0
    fi
    
    echo -e "${YELLOW}⏳ Waiting for application to start... (${counter}s/${timeout}s)${NC}"
    sleep 2
    counter=$((counter + 2))
done

echo -e "${RED}❌ Application failed to start within ${timeout} seconds${NC}"
echo -e "${YELLOW}📋 Check logs: docker-compose -f docker-compose.production.yml logs${NC}"
exit 1
