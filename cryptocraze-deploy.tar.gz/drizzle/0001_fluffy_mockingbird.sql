DROP TABLE "achievements" CASCADE;--> statement-breakpoint
DROP TABLE "daily_rewards" CASCADE;--> statement-breakpoint
DROP TABLE "loot_boxes" CASCADE;--> statement-breakpoint
DROP TABLE "price_history" CASCADE;--> statement-breakpoint
DROP TABLE "trades" CASCADE;--> statement-breakpoint
DROP TABLE "trading_pairs" CASCADE;--> statement-breakpoint
DROP TABLE "user_achievements" CASCADE;--> statement-breakpoint
DROP TABLE "user_loot_history" CASCADE;